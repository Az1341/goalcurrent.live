"use client";

import TeamFlag from "@/components/TeamFlag";
import TeamLink from "@/components/wc26/TeamLink";
import { FavouriteMatchButton } from "@/components/FavouriteButton";
import { getTeamById } from "@/data/wc26";
import type { MatchDetailPayload } from "@/types/match-detail";
import { extractMatchGoalSummary } from "./match-goal-summary";
import {
  resolveTimelineEventDisplay,
  resolveEventSide,
  sortTimelineEvents,
  type TimelineEventDisplay,
  type TimelineEventSide,
} from "./timeline-event-badge";
import styles from "./match.module.css";

import type { HomepageMatchView } from "@/lib/wc26-live";

const API_UNAVAILABLE_MESSAGE =
  "Unable to load match details from the API. Try refreshing the page.";

function detailEmptyMessage(
  detail: MatchDetailPayload,
  emptyConfigured: string,
  emptyUnconfigured: string,
): string {
  if (detail.configured && !detail.apiAvailable) {
    return API_UNAVAILABLE_MESSAGE;
  }
  if (detail.configured) {
    return emptyConfigured;
  }
  return emptyUnconfigured;
}

type MatchDetailHeaderProps = {
  header: HomepageMatchView;
  detail: MatchDetailPayload;
  loading: boolean;
};

export function MatchDetailHeader({ header, detail, loading }: MatchDetailHeaderProps) {
  const isLive = header.matchClass === "live";
  const isFinishedOrLive = header.matchClass === "live" || header.matchClass === "ft";
  const scoreText = header.score
    ? `${header.score.home} – ${header.score.away}`
    : "vs";

  const goalSummary =
    !loading && isFinishedOrLive
      ? extractMatchGoalSummary(
          detail.events,
          header.homeName,
          header.awayName,
          detail.lineups.home?.teamName ?? null,
          detail.lineups.away?.teamName ?? null,
        )
      : null;

  const showGoalSummary =
    goalSummary != null && (goalSummary.home.length > 0 || goalSummary.away.length > 0);

  return (
    <section className={styles.headerCard} aria-labelledby="match-header-title">
      <div className={styles.headerTop}>
        <div>
          <div id="match-header-title" style={{ fontWeight: 600 }}>
            {isLive ? "Live match" : "Match centre"}
          </div>
          <div className={styles.headerMeta}>{header.roundLabel}</div>
        </div>
        <FavouriteMatchButton
          matchId={header.fixtureId}
          label={`${header.homeName} vs ${header.awayName}`}
        />
      </div>
      <div className={styles.headerBody}>
        <div className={styles.teamsRow}>
          <div className={styles.teamCol}>
            <TeamLink teamId={header.homeTeamId} className={styles.teamNameLink}>
              <TeamFlag teamId={header.homeTeamId} size={48} />
              <div className={styles.teamName}>{header.homeName}</div>
            </TeamLink>
            {showGoalSummary && goalSummary!.home.length > 0 ? (
              <ul className={styles.headerScorers} aria-label={`${header.homeName} goal scorers`}>
                {goalSummary!.home.map((line) => (
                  <li
                    key={`home-${line.minute}-${line.playerName}`}
                    className={styles.headerScorerLine}
                  >
                    <span className={styles.headerScorerIcon} aria-hidden="true">
                      {line.symbol}
                    </span>
                    <span className={styles.headerScorerPlayer}>{line.playerName}</span>
                    <span className={styles.headerScorerMinute}>{line.minute}</span>
                  </li>
                ))}
              </ul>
            ) : null}
          </div>
          <div className={styles.scoreCol}>
            <div className={styles.scoreMain}>{scoreText}</div>
            <div className={styles.scoreSub}>
              {header.statusLabel}
              {header.elapsed != null && isLive ? ` · ${header.elapsed}'` : ""}
            </div>
          </div>
          <div className={`${styles.teamCol} ${styles.teamColAway}`}>
            <TeamLink teamId={header.awayTeamId} className={styles.teamNameLink}>
              <TeamFlag teamId={header.awayTeamId} size={48} />
              <div className={styles.teamName}>{header.awayName}</div>
            </TeamLink>
            {showGoalSummary && goalSummary!.away.length > 0 ? (
              <ul className={`${styles.headerScorers} ${styles.headerScorersAway}`} aria-label={`${header.awayName} goal scorers`}>
                {goalSummary!.away.map((line) => (
                  <li
                    key={`away-${line.minute}-${line.playerName}`}
                    className={styles.headerScorerLine}
                  >
                    <span className={styles.headerScorerIcon} aria-hidden="true">
                      {line.symbol}
                    </span>
                    <span className={styles.headerScorerPlayer}>{line.playerName}</span>
                    <span className={styles.headerScorerMinute}>{line.minute}</span>
                  </li>
                ))}
              </ul>
            ) : null}
          </div>
        </div>
        <p className={styles.kickoffLine}>
          {header.kickoffLabel}
          {header.venueLabel ? ` · ${header.venueLabel}` : ""}
        </p>
      </div>
    </section>
  );
}

type MatchTimelineProps = {
  detail: MatchDetailPayload;
  loading: boolean;
  homeTeamName: string;
  awayTeamName: string;
};

const TIMELINE_TONE_CLASS: Record<TimelineEventDisplay["badge"]["tone"], string> = {
  goal: styles.timelineCardGoal,
  penalty: styles.timelineCardPenalty,
  "penalty-missed": styles.timelineCardPenaltyMissed,
  "own-goal": styles.timelineCardOwnGoal,
  "var-denied": styles.timelineCardVarDenied,
  var: styles.timelineCardVar,
  subst: styles.timelineCardSubst,
  yellow: styles.timelineCardYellow,
  red: styles.timelineCardRed,
  "second-yellow": styles.timelineCardSecondYellow,
  injury: styles.timelineCardInjury,
  period: styles.timelineCardPeriod,
  neutral: styles.timelineCardNeutral,
};

const TIMELINE_ICON_CLASS: Record<TimelineEventDisplay["badge"]["tone"], string> = {
  goal: styles.timelineIconGoal,
  penalty: styles.timelineIconPenalty,
  "penalty-missed": styles.timelineIconPenaltyMissed,
  "own-goal": styles.timelineIconOwnGoal,
  "var-denied": styles.timelineIconVarDenied,
  var: styles.timelineIconVar,
  subst: styles.timelineIconSubst,
  yellow: styles.timelineIconYellow,
  red: styles.timelineIconRed,
  "second-yellow": styles.timelineIconSecondYellow,
  injury: styles.timelineIconInjury,
  period: styles.timelineIconPeriod,
  neutral: styles.timelineIconNeutral,
};

function TimelineEventIcon({ display }: { display: TimelineEventDisplay }) {
  return (
    <span
      className={[
        styles.timelineIcon,
        display.badge.variant === "text" ? styles.timelineIconText : "",
        TIMELINE_ICON_CLASS[display.badge.tone],
      ]
        .filter(Boolean)
        .join(" ")}
      aria-label={display.badge.ariaLabel}
      title={display.badge.ariaLabel}
    >
      <span className={styles.timelineIconSymbol} aria-hidden="true">
        {display.badge.symbol}
      </span>
      {display.badge.secondarySymbol ? (
        <span className={styles.timelineIconSymbolSecondary} aria-hidden="true">
          {display.badge.secondarySymbol}
        </span>
      ) : null}
    </span>
  );
}

function TimelineEventCard({
  display,
  side,
}: {
  display: TimelineEventDisplay;
  side: TimelineEventSide;
}) {
  const isAway = side === "away";
  const cardClassName = [
    styles.timelineCard,
    isAway ? styles.timelineCardAway : styles.timelineCardHome,
    display.isGoal ? styles.timelineCardHighlight : "",
    TIMELINE_TONE_CLASS[display.badge.tone],
  ]
    .filter(Boolean)
    .join(" ");

  return (
    <article className={cardClassName}>
      <div className={styles.timelineCardRow}>
        <TimelineEventIcon display={display} />
        <div className={styles.timelineContent}>
          {display.playerName ? (
            <div className={styles.timelinePlayer}>{display.playerName}</div>
          ) : null}
          <div className={styles.timelineTitle}>{display.title}</div>
          {display.assistLabel ? (
            <div className={styles.timelineAssist}>{display.assistLabel}</div>
          ) : null}
        </div>
      </div>
    </article>
  );
}

export function MatchTimeline({
  detail,
  loading,
  homeTeamName,
  awayTeamName,
}: MatchTimelineProps) {
  const lineupHomeName = detail.lineups.home?.teamName ?? null;
  const lineupAwayName = detail.lineups.away?.teamName ?? null;
  const sortedEvents = sortTimelineEvents(detail.events);

  return (
    <section className={styles.section} aria-labelledby="match-timeline-heading">
      <h2 id="match-timeline-heading" className={styles.sectionTitle}>
        Match timeline
      </h2>
      <div className={styles.panel}>
        {loading ? (
          <p className={styles.emptyState}>Loading match events…</p>
        ) : detail.events.length === 0 ? (
          <p className={styles.emptyState}>
            {detailEmptyMessage(
              detail,
              "No events recorded yet. Goals, cards and substitutions will appear here when the live feed provides them.",
              "Match events will appear when server API sync is configured and the match is underway or finished.",
            )}
          </p>
        ) : (
          <div className={styles.timelineBoard}>
            <div className={styles.timelineBoardHeader} aria-hidden="true">
              <span className={styles.timelineBoardTeamHome}>{homeTeamName}</span>
              <span className={styles.timelineBoardCenter}>Timeline</span>
              <span className={styles.timelineBoardTeamAway}>{awayTeamName}</span>
            </div>
            <ol className={styles.timelineRows}>
              {sortedEvents.map((event, index) => {
                const display = resolveTimelineEventDisplay(event);
                const side = display.isPeriod
                  ? "neutral"
                  : resolveEventSide(
                      display.teamName,
                      homeTeamName,
                      awayTeamName,
                      lineupHomeName,
                      lineupAwayName,
                    );

                if (display.isPeriod) {
                  return (
                    <li
                      key={`period-${display.minute}-${index}`}
                      className={[styles.timelineRow, styles.timelineRowPeriod]
                        .filter(Boolean)
                        .join(" ")}
                    >
                      <div className={styles.timelineColPeriod}>
                        <article className={`${styles.timelineCard} ${styles.timelineCardPeriod}`}>
                          <TimelineEventIcon display={display} />
                          <span className={styles.timelinePeriodLabel}>{display.title}</span>
                        </article>
                      </div>
                    </li>
                  );
                }

                return (
                  <li
                    key={`${event.minute}-${event.extra ?? 0}-${event.playerName}-${index}`}
                    className={styles.timelineRow}
                  >
                    <div className={styles.timelineColHome}>
                      {side === "home" ? (
                        <TimelineEventCard display={display} side="home" />
                      ) : null}
                    </div>
                    <div className={styles.timelineColCenter}>
                      <span className={styles.timelineMinuteCenter}>{display.minute}</span>
                    </div>
                    <div className={styles.timelineColAway}>
                      {side === "away" ? (
                        <TimelineEventCard display={display} side="away" />
                      ) : null}
                    </div>
                  </li>
                );
              })}
            </ol>
          </div>
        )}
      </div>
    </section>
  );
}

type MatchStatisticsProps = {
  detail: MatchDetailPayload;
  loading: boolean;
};

export function MatchStatistics({ detail, loading }: MatchStatisticsProps) {
  return (
    <section className={styles.section} aria-labelledby="match-stats-heading">
      <h2 id="match-stats-heading" className={styles.sectionTitle}>
        Statistics
      </h2>
      <div className={styles.panel}>
        {loading ? (
          <p className={styles.emptyState}>Loading statistics…</p>
        ) : detail.statistics.length === 0 ? (
          <p className={styles.emptyState}>
            {detailEmptyMessage(
              detail,
              "Team statistics will appear when the match is in progress or completed and the API feed is available.",
              "Team statistics will appear when server API sync is configured and the match is underway or finished.",
            )}
          </p>
        ) : (
          detail.statistics.map((stat) => (
            <div key={stat.key} className={styles.statRow}>
              <span className={styles.statHome}>{stat.home ?? "–"}</span>
              <span className={styles.statLabel}>{stat.label}</span>
              <span className={styles.statAway}>{stat.away ?? "–"}</span>
            </div>
          ))
        )}
      </div>
    </section>
  );
}

type MatchLineupsProps = {
  detail: MatchDetailPayload;
  homeTeamId: string;
  awayTeamId: string;
  loading: boolean;
};

function LineupBlock({
  title,
  side,
}: {
  title: string;
  side: MatchDetailPayload["lineups"]["home"];
}) {
  if (!side) {
    return (
      <div className={styles.lineupSide}>
        <h3>{title}</h3>
        <p className={styles.emptyState}>Lineup not available yet.</p>
      </div>
    );
  }

  return (
    <div className={styles.lineupSide}>
      <h3>{title}</h3>
      <p className={styles.lineupMeta}>
        {side.formation ? `Formation ${side.formation}` : "Formation TBC"}
        {side.coach ? ` · ${side.coach}` : ""}
      </p>
      <p className={styles.lineupMeta}>Starting XI</p>
      <ul className={styles.lineupList}>
        {side.startXI.map((player) => (
          <li key={`${player.number}-${player.name}`} className={styles.lineupPlayer}>
            <span className={styles.lineupNum}>{player.number ?? "–"}</span>
            <span>
              {player.name}
              {player.position ? ` (${player.position})` : ""}
            </span>
          </li>
        ))}
      </ul>
      {side.substitutes.length > 0 ? (
        <>
          <p className={styles.lineupMeta} style={{ marginTop: 12 }}>
            Bench
          </p>
          <ul className={styles.lineupList}>
            {side.substitutes.map((player) => (
              <li key={`sub-${player.number}-${player.name}`} className={styles.lineupPlayer}>
                <span className={styles.lineupNum}>{player.number ?? "–"}</span>
                <span>{player.name}</span>
              </li>
            ))}
          </ul>
        </>
      ) : null}
    </div>
  );
}

export function MatchLineups({
  detail,
  homeTeamId,
  awayTeamId,
  loading,
}: MatchLineupsProps) {
  const home = getTeamById(homeTeamId);
  const away = getTeamById(awayTeamId);

  return (
    <section className={styles.section} aria-labelledby="match-lineups-heading">
      <h2 id="match-lineups-heading" className={styles.sectionTitle}>
        Lineups
      </h2>
      <div className={styles.panel}>
        {loading ? (
          <p className={styles.emptyState}>Loading lineups…</p>
        ) : !detail.lineups.home && !detail.lineups.away ? (
          <p className={styles.emptyState}>
            {detailEmptyMessage(
              detail,
              "Lineups will be published closer to kickoff when the API feed is available.",
              "Lineups will appear when server API sync is configured and the match is underway or finished.",
            )}
          </p>
        ) : (
          <div className={styles.lineupGrid}>
            <LineupBlock title={home?.name ?? "Home"} side={detail.lineups.home} />
            <LineupBlock title={away?.name ?? "Away"} side={detail.lineups.away} />
          </div>
        )}
      </div>
    </section>
  );
}
